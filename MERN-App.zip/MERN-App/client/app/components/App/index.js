import React, { Component } from 'react';

const App = ({ children }) => (
    <>
      <main>
        {children}
      </main>
    </>
  );
  
  export default App;